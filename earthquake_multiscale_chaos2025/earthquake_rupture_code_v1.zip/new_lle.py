#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Sliding-window Lyapunov estimation using your lyapunov_kit_v2_2 module.

- Input:  Data.csv  (3 columns: time, Mw, dMw)
- Core:   get_lyap_knn_microseries → y(h) points; fit_best_slope → 1 vs 2 lines
- Output: results/win{WIN}_mode{MODE}_lb{LB}_h{HMAX}_{UNIX}/
          ├── lyap_Mw.csv
          ├── lyap_dMw.csv
          ├── lyap_Mw.png
          ├── lyap_dMw.png
          ├── config.json
          ├── profiles_Mw/   (every 4th window: y(h) + fit)
          └── profiles_dMw/

Lyapunov estimate reported in CSV ("lyap") is the LEFT-slope if two lines are chosen,
otherwise the single-line slope. Full diagnostics are also saved.
"""

import os
import json
import time
from typing import Literal, List, Tuple, Optional, Dict, Any

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---- use ONLY your production module ----
from lyapunov_kit_v2_2 import (
    get_lyap_knn_microseries,   # batched KNN over microseries
    fit_best_slope,             # choose 1 or 2 lines by MAE criterion
    _polyfit_unconstrained,     # linear fit helper (for right-slope)
    # get_lyap_knn              # optional, not used here but available
)

# ================== CONFIG ==================

DATA_FILE    = "Data.csv"      # should be alongside the script
RESULTS_ROOT = "results_new"

# sliding-window length (over the original ~559-point series)
WINDOW_LEN = 100

# microseries / KNN settings
BASE_LOOK_BACK = 1
BASE_HMIN      = 1
BASE_HMAX      = 10            # as requested
BASE_HSTEP     = 1
BASE_NEIGHBORS = 3
BASE_TEST_SIZE = 0.40

# modes: "raw" (no normalization) or "norm" (amplitude-normalize each microseries)
MODE: Literal["raw", "norm"] = "raw"
#MODE: Literal["raw", "norm"] = "norm"

# Save every Nth y(h) profile (plus first and last windows)
PROFILE_EVERY = 4

# ============================================

def load_data(path: str) -> np.ndarray:
    """Load 3-column CSV: time, Mw, dMw."""
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Data file not found: {path}")
    data = np.loadtxt(path, delimiter=",", dtype=float)
    if data.ndim != 2 or data.shape[1] < 3:
        raise ValueError(f"Expected 3 columns (time, Mw, dMw), got shape {data.shape}")
    return data[:, :3]  # (N, 3)


def make_micro_from_window(
    window: np.ndarray,
    *,
    look_back: int,
    hmax: int,
    normalize: bool,
) -> np.ndarray:
    """
    Convert a 1D window into overlapping microseries of length L=look_back+hmax.
    If normalize=True, each microseries is divided by its own max |value|.
    Return shape: (n_samples, L) or (0, L) if not enough.
    """
    L = look_back + hmax
    W = int(window.shape[0])
    if W < L:
        return np.empty((0, L), dtype=float)

    micro_list: List[np.ndarray] = []
    for start in range(0, W - L + 1):
        ms = window[start:start + L].astype(float)
        if normalize:
            m = np.max(np.abs(ms))
            if m > 0:
                ms = ms / m
        micro_list.append(ms)

    return np.vstack(micro_list)


def _y_from_points(points: List[List[float]], *, hmin: int, hmax: int, hstep: int) -> np.ndarray:
    """
    Convert list of [h, y] to dense y(h) vector over hmin..hmax with step hstep.
    Missing h become NaN.
    """
    h2y = {int(h): float(y) for (h, y) in (points or [])}
    hs  = list(range(hmin, hmax + 1, hstep))
    return np.asarray([h2y.get(h, float("nan")) for h in hs], dtype=float)


def _right_slope_if_two_lines(
    yvec: np.ndarray, *, hmin: int, hmax: int, hstep: int, split_h: Optional[float]
) -> float:
    """
    Return the slope of the RIGHT segment when a two-line model is chosen.
    If not computable, return NaN.
    """
    if split_h is None or not np.isfinite(split_h):
        return np.nan
    hh = np.arange(hmin, hmax + 1, hstep, dtype=float)
    yv = np.asarray(yvec, float)
    # first index where hh >= split_h
    idx_split = int(np.argmax(hh >= split_h))
    if idx_split < 0 or idx_split >= hh.size:
        return np.nan
    yR_obs = yv[idx_split:]
    mR = np.isfinite(yR_obs)
    if mR.sum() < 2:
        return np.nan
    hR = hh[idx_split:][mR]
    yR = yR_obs[mR]
    a2, b2 = _polyfit_unconstrained(hR, yR)
    return float(a2)


def plot_y_profile(
    out_png: str,
    hmin: int, hmax: int, hstep: int,
    yvec: np.ndarray,
    lines_used: int,
    split_h: Optional[float],
    slope_one_or_left: float,
    slope_right: Optional[float],
):
    """Plot y(h) with the chosen fit(s)."""
    hs = np.arange(hmin, hmax + 1, hstep, dtype=float)
    y  = np.asarray(yvec, float)

    plt.figure(figsize=(5.6, 4.2))
    plt.plot(hs, y, "o-", lw=1.4, label="y(h) = log GME(error)")

    if lines_used == 1:
        # re-fit for plotting to get intercept together with slope
        a, b = _polyfit_unconstrained(hs[np.isfinite(y)], y[np.isfinite(y)])
        if not np.isfinite(a):
            a, b = slope_one_or_left, 0.0
        yhat = a * hs + b
        plt.plot(hs, yhat, "-", label=f"1-line fit: slope = {a:.4g}")
    else:
        # left segment
        if split_h is None or not np.isfinite(split_h):
            split_h = float(hmin + (hmax - hmin)//2)
        mL = hs <= split_h
        aL, bL = _polyfit_unconstrained(hs[mL & np.isfinite(y)], y[mL & np.isfinite(y)])
        if not np.isfinite(aL):
            aL, bL = slope_one_or_left, 0.0
        plt.plot(hs[mL], aL*hs[mL] + bL, "-", label=f"left: slope = {aL:.4g}")
        # right segment (if available)
        if slope_right is not None and np.isfinite(slope_right):
            mR = hs >= split_h
            aR, bR = _polyfit_unconstrained(hs[mR & np.isfinite(y)], y[mR & np.isfinite(y)])
            if not np.isfinite(aR):
                aR, bR = slope_right, 0.0
            plt.plot(hs[mR], aR*hs[mR] + bR, "-", label=f"right: slope = {aR:.4g}")
        plt.axvline(split_h, color="gray", ls="--", lw=1.0, alpha=0.6)

    plt.xlabel("forecast horizon h")
    plt.ylabel("y(h)  (log geometric-mean error)")
    plt.grid(alpha=0.3)
    plt.legend(loc="best")
    plt.tight_layout()
    plt.savefig(out_png, dpi=170)
    plt.close()


def process_series(
    time_vec: np.ndarray,
    series: np.ndarray,
    *,
    win_len: int,
    look_back: int,
    hmin: int,
    hmax: int,
    hstep: int,
    neighbors: int,
    test_size: float,
    normalize: bool,
    out_profiles_dir: str,
    profile_every: int,
):
    """
    Returns:
      centers:   (K,) time values at window centers
      lyaps:     (K,) reported Lyapunov slope (single or LEFT if 2 lines)
      counts:    (K,) number of microseries used in each window
      lines:     (K,) 1 or 2 (model chosen)
      splits:    (K,) split location (or NaN)
      slopeL:    (K,) left slope (or NaN if 1-line)
      slopeR:    (K,) right slope (or NaN if 1-line)

    Also writes profile PNG/CSV for sampled windows into out_profiles_dir.
    """
    N = series.shape[0]
    os.makedirs(out_profiles_dir, exist_ok=True)

    centers:   List[float] = []
    lyaps:     List[float] = []
    counts:    List[int]   = []
    lines_use: List[int]   = []
    splits:    List[float] = []
    slopeL:    List[float] = []
    slopeR:    List[float] = []

    idx = 0
    for start in range(0, N - win_len + 1):
        stop = start + win_len
        win = series[start:stop]
        t_center = time_vec[start + win_len // 2]

        # build microseries from this window
        micro = make_micro_from_window(
            win, look_back=look_back, hmax=hmax, normalize=normalize
        )
        n_micro = int(micro.shape[0])

        lam = np.nan
        lines_used, split_h = 0, np.nan
        aL_val, aR_val = np.nan, np.nan

        if n_micro >= 2:
            try:
                # compute KNN y(h) points (log-GME vs horizon)
                points, _ = get_lyap_knn_microseries(
                    microseries=micro,
                    look_back=look_back,
                    test_size=test_size,
                    neighbors=neighbors,
                    horizon_min=hmin,
                    horizon_max=hmax,
                    horizon_step=hstep,
                )
                yvec = _y_from_points(points, hmin=hmin, hmax=hmax, hstep=hstep)

                # choose 1-line vs 2-line by MAE (module's fit_best_slope)
                a_fit, b_fit, lines_used, split_val, _ = fit_best_slope(
                    yvec, hmin=hmin, hmax=hmax, hstep=hstep
                )

                # reported Lyapunov estimate is the 1-line slope or LEFT slope
                lam = float(a_fit) if (a_fit is not None) else np.nan
                split_h = float(split_val) if (split_val is not None) else np.nan

                # store left/right slopes for diagnostics
                aL_val = lam
                aR_val = (
                    _right_slope_if_two_lines(
                        yvec, hmin=hmin, hmax=hmax, hstep=hstep, split_h=split_val
                    )
                    if lines_used == 2 else np.nan
                )

                # Dump y(h) every PROFILE_EVERY-th window (plus first/last)
                save_profile = (idx % max(1, profile_every) == 0) or (start == 0) or (stop == N)
                if save_profile:
                    # CSV
                    prof_csv = os.path.join(out_profiles_dir, f"profile_{idx:04d}.csv")
                    with open(prof_csv, "w", encoding="utf-8") as fcsv:
                        fcsv.write("h,y\n")
                        hs = np.arange(hmin, hmax + 1, hstep, dtype=float)
                        for h, y in zip(hs, yvec):
                            fcsv.write(f"{h},{'' if not np.isfinite(y) else y}\n")
                    # PNG
                    prof_png = os.path.join(out_profiles_dir, f"profile_{idx:04d}.png")
                    plot_y_profile(
                        out_png=prof_png,
                        hmin=hmin, hmax=hmax, hstep=hstep,
                        yvec=yvec,
                        lines_used=lines_used,
                        split_h=split_val,
                        slope_one_or_left=lam,
                        slope_right=aR_val if np.isfinite(aR_val) else None,
                    )
            except Exception:
                pass

        centers.append(float(t_center))
        lyaps.append(float(lam))
        counts.append(n_micro)
        lines_use.append(int(lines_used))
        splits.append(float(split_h))
        slopeL.append(float(aL_val))
        slopeR.append(float(aR_val))

        idx += 1

    return (
        np.asarray(centers, float),
        np.asarray(lyaps, float),
        np.asarray(counts, int),
        np.asarray(lines_use, int),
        np.asarray(splits, float),
        np.asarray(slopeL, float),
        np.asarray(slopeR, float),
    )


def plot_curve(x, y, title: str, out_path: str):
    plt.figure(figsize=(8.4, 4.2))
    plt.plot(x, y, marker="o", lw=1.2)
    plt.xlabel("time (years)")
    plt.ylabel("λ estimate (KNN microseries)")
    plt.title(title)
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=170)
    plt.close()


def main():
    data = load_data(DATA_FILE)
    t   = data[:, 0]
    mw  = data[:, 1]
    dmw = data[:, 2]

    ts = int(time.time())
    run_name = f"win{WINDOW_LEN}_mode{MODE}_lb{BASE_LOOK_BACK}_h{BASE_HMAX}_{ts}"
    out_dir  = os.path.join(RESULTS_ROOT, run_name)
    os.makedirs(out_dir, exist_ok=True)

    # ---- Mw ----
    profiles_mw = os.path.join(out_dir, "profiles_Mw")
    (centers_mw, lyap_mw, cnt_mw, lines_mw, split_mw, slopeL_mw, slopeR_mw) = process_series(
        time_vec=t,
        series=mw,
        win_len=WINDOW_LEN,
        look_back=BASE_LOOK_BACK,
        hmin=BASE_HMIN,
        hmax=BASE_HMAX,
        hstep=BASE_HSTEP,
        neighbors=BASE_NEIGHBORS,
        test_size=BASE_TEST_SIZE,
        normalize=(MODE == "norm"),
        out_profiles_dir=profiles_mw,
        profile_every=PROFILE_EVERY,
    )

    # ---- dMw ----
    profiles_dmw = os.path.join(out_dir, "profiles_dMw")
    (centers_dmw, lyap_dmw, cnt_dmw, lines_dmw, split_dmw, slopeL_dmw, slopeR_dmw) = process_series(
        time_vec=t,
        series=dmw,
        win_len=WINDOW_LEN,
        look_back=BASE_LOOK_BACK,
        hmin=BASE_HMIN,
        hmax=BASE_HMAX,
        hstep=BASE_HSTEP,
        neighbors=BASE_NEIGHBORS,
        test_size=BASE_TEST_SIZE,
        normalize=(MODE == "norm"),
        out_profiles_dir=profiles_dmw,
        profile_every=PROFILE_EVERY,
    )

    # ---- CSVs ----
    mw_csv = os.path.join(out_dir, "lyap_Mw.csv")
    with open(mw_csv, "w", encoding="utf-8") as f:
        f.write("time,lyap,lines_used,split_h,slope_left,slope_right,n_micro\n")
        for tt, ll, lu, sh, sl, sr, cc in zip(
            centers_mw, lyap_mw, lines_mw, split_mw, slopeL_mw, slopeR_mw, cnt_mw
        ):
            f.write(
                f"{tt:.9g},"
                f"{'' if not np.isfinite(ll) else f'{ll:.12g}'},"
                f"{lu},"
                f"{'' if not np.isfinite(sh) else f'{sh:.9g}'},"
                f"{'' if not np.isfinite(sl) else f'{sl:.12g}'},"
                f"{'' if not np.isfinite(sr) else f'{sr:.12g}'},"
                f"{cc}\n"
            )

    dmw_csv = os.path.join(out_dir, "lyap_dMw.csv")
    with open(dmw_csv, "w", encoding="utf-8") as f:
        f.write("time,lyap,lines_used,split_h,slope_left,slope_right,n_micro\n")
        for tt, ll, lu, sh, sl, sr, cc in zip(
            centers_dmw, lyap_dmw, lines_dmw, split_dmw, slopeL_dmw, slopeR_dmw, cnt_dmw
        ):
            f.write(
                f"{tt:.9g},"
                f"{'' if not np.isfinite(ll) else f'{ll:.12g}'},"
                f"{lu},"
                f"{'' if not np.isfinite(sh) else f'{sh:.9g}'},"
                f"{'' if not np.isfinite(sl) else f'{sl:.12g}'},"
                f"{'' if not np.isfinite(sr) else f'{sr:.12g}'},"
                f"{cc}\n"
            )

    # ---- PNGs ----
    title_common = (
        f"win={WINDOW_LEN}, mode={MODE}, lb={BASE_LOOK_BACK}, "
        f"h=({BASE_HMIN}..{BASE_HMAX}), k={BASE_NEIGHBORS}"
    )
    plot_curve(
        centers_mw, lyap_mw,
        title=f"Mw: {title_common}",
        out_path=os.path.join(out_dir, "lyap_Mw.png"),
    )
    plot_curve(
        centers_dmw, lyap_dmw,
        title=f"ΔMw: {title_common}",
        out_path=os.path.join(out_dir, "lyap_dMw.png"),
    )

    # ---- JSON ----
    cfg = {
        "data_file": os.path.abspath(DATA_FILE),
        "output_dir": os.path.abspath(out_dir),
        "window_len": WINDOW_LEN,
        "mode": MODE,
        "look_back": BASE_LOOK_BACK,
        "hmin": BASE_HMIN,
        "hmax": BASE_HMAX,
        "hstep": BASE_HSTEP,
        "neighbors": BASE_NEIGHBORS,
        "test_size": BASE_TEST_SIZE,
        "profile_every": PROFILE_EVERY,
        "timestamp": ts,
        "n_points": int(data.shape[0]),
    }
    with open(os.path.join(out_dir, "config.json"), "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

    print(f"[ok] saved to: {out_dir}")


if __name__ == "__main__":
    main()
